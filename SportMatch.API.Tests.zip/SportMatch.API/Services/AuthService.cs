using SportMatch.API.Models;
using SportMatch.API.Repositories;

namespace SportMatch.API.Services;

public class AuthService : IAuthService
{
    private readonly IAccountRepository _accountRepository;
    private readonly ICryptService _cryptService;

    public AuthService(IAccountRepository accountRepository, ICryptService cryptService)
    {
        _accountRepository = accountRepository;
        _cryptService = cryptService;
    }

    public bool CheckLogin(Account? account, string password)
    {
        if (account is null || password is null)
            return false;

        return _cryptService.VerifyHash(password, account.PasswordHash);
    }

    public async Task<bool> CheckLoginAsync(string username, string password)
    {
        var account = await _accountRepository.GetByUsernameAsync(username);
        return CheckLogin(account, password);
    }

    public async Task<string?> LoginAsync(string username, string password)
    {
        var account = await _accountRepository.GetByUsernameAsync(username);
        if (account is null || !CheckLogin(account, password))
            return null;

        return _cryptService.GenerateToken(account);
    }
}
