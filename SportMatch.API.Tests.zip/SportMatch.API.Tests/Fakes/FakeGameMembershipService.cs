using SportMatch.API.DataTransferObjects.Responses;
using SportMatch.API.Models;
using SportMatch.API.Results;
using SportMatch.API.Services;

namespace SportMatch.API.Tests.Fakes;

// fake service for controller tests: it has no join/leave rules,
// it just returns what the test sets and remembers what the controller sent
public class FakeGameMembershipService : IGameMembershipService
{
<<<<<<< HEAD
    // what JoinAsync and LeaveAsync return
=======
    // what Join, Leave and Kick return
>>>>>>> origin/main
    public MembershipResult Result { get; set; } = MembershipResult.Success;

    // what GetGameAsync and GetSpotsAsync return
    public Game? Game { get; set; }
    public GameSpots? Spots { get; set; }

<<<<<<< HEAD
    // what the controller passed to JoinAsync or LeaveAsync
=======
    // what the controller passed to Join, Leave or Kick
>>>>>>> origin/main
    public int LastGameId { get; private set; }
    public string? LastUsername { get; private set; }

    // returns the game only when the controller asked for the right id
    public Task<Game?> GetGameAsync(int gameId)
    {
        if (Game is not null && Game.Id == gameId)
            return Task.FromResult<Game?>(Game);

        return Task.FromResult<Game?>(null);
    }

    public int GetFreeSpots(Game game) => game.MaxPlayers - game.JoinedUsernames.Count;

    public Task<GameSpots?> GetSpotsAsync(int gameId)
    {
        LastGameId = gameId;
        return Task.FromResult(Spots);
    }

    public Task<MembershipResult> JoinAsync(int gameId, string username)
    {
        LastGameId = gameId;
        LastUsername = username;
        return Task.FromResult(Result);
    }

    public Task<MembershipResult> LeaveAsync(int gameId, string username)
    {
        LastGameId = gameId;
        LastUsername = username;
        return Task.FromResult(Result);
    }
<<<<<<< HEAD
}
=======

    public MembershipResult Kick(int gameId, string hostUsername, string username)
    {
        LastGameId = gameId;
        LastUsername = username;
        return Result;
    }
}
>>>>>>> origin/main
